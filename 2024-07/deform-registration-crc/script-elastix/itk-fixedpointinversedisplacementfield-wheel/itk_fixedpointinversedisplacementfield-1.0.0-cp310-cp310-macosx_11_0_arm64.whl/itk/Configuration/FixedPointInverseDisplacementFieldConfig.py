depends = ('ITKPyBase', 'ITKImageGrid', 'ITKIOImageBase', 'ITKCommon', )
templates = (  ('FixedPointInverseDisplacementFieldImageFilter', 'itk::FixedPointInverseDisplacementFieldImageFilter', 'itkFixedPointInverseDisplacementFieldImageFilterIVF22IVF22', True, 'itk::Image< itk::Vector< float,2 >,2 >, itk::Image< itk::Vector< float,2 >,2 >'),
  ('FixedPointInverseDisplacementFieldImageFilter', 'itk::FixedPointInverseDisplacementFieldImageFilter', 'itkFixedPointInverseDisplacementFieldImageFilterIVF33IVF33', True, 'itk::Image< itk::Vector< float,3 >,3 >, itk::Image< itk::Vector< float,3 >,3 >'),
  ('FixedPointInverseDisplacementFieldImageFilter', 'itk::FixedPointInverseDisplacementFieldImageFilter', 'itkFixedPointInverseDisplacementFieldImageFilterIVF44IVF44', True, 'itk::Image< itk::Vector< float,4 >,4 >, itk::Image< itk::Vector< float,4 >,4 >'),
)
factories = ()
